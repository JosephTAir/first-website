function add(x, y) {
  let addition = x + y;
  console.log(addition);
}
add(550, 123);